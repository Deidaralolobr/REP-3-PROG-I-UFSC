#ifndef MENUS_H
#define MENUS_H

#include <stddef.h>

uint8_t menu_principal();
uint8_t menu_relatorios();
uint8_t menu_cadastros();
uint8_t menu_consultas();
uint8_t manipulacao_arquivos();


#endif